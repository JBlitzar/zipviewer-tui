# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "pygame",
# ]
# ///
import pygame
import random
import sys

# Initialize Pygame
pygame.init()

# Game constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
GRID_SIZE = 20
FPS = 10

# Colors
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)
DARK_GREEN = (0, 200, 0)

# Color palettes for random colors
VIBRANT_COLORS = [
    (255, 100, 100),  # Light red
    (100, 255, 100),  # Light green
    (100, 100, 255),  # Light blue
    (255, 255, 100),  # Yellow
    (255, 100, 255),  # Magenta
    (100, 255, 255),  # Cyan
    (255, 150, 100),  # Orange
    (150, 100, 255),  # Purple
    (255, 200, 200),  # Pink
    (200, 255, 200),  # Light green
]

FOOD_COLORS = [
    (255, 0, 0),      # Red
    (255, 165, 0),    # Orange
    (255, 255, 0),    # Yellow
    (255, 20, 147),   # Deep pink
    (138, 43, 226),   # Blue violet
    (0, 191, 255),    # Deep sky blue
    (50, 205, 50),    # Lime green
    (0, 255, 255),     # bright bright cyan
(255, 0, 255) # shader death magenta
]

def get_random_color(color_list):
    return random.choice(color_list)

class Snake:
    def __init__(self):
        self.positions = [(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2)]
        self.direction = (GRID_SIZE, 0)  # Moving right initially
        self.grow = False
        self.head_color = get_random_color(VIBRANT_COLORS)
        self.body_colors = []  # Store colors for each body segment
        
    def move(self):
        head_x, head_y = self.positions[0]
        new_head = (head_x + self.direction[0], head_y + self.direction[1])
        
        # Check wall collision
        if (new_head[0] < 0 or new_head[0] >= WINDOW_WIDTH or 
            new_head[1] < 0 or new_head[1] >= WINDOW_HEIGHT):
            return False
            
        # Check self collision
        if new_head in self.positions:
            return False
            
        self.positions.insert(0, new_head)
        
        if not self.grow:
            self.positions.pop()
        else:
            self.grow = False
            
        return True
    
    def change_direction(self, direction):
        # Prevent moving in opposite direction
        if (direction[0] * -1, direction[1] * -1) != self.direction:
            self.direction = direction
    
    def grow_snake(self):
        self.grow = True
        # Add a new random color for the new body segment
        self.body_colors.append(get_random_color(VIBRANT_COLORS))
    
    def draw(self, screen):
        for i, position in enumerate(self.positions):
            rect = pygame.Rect(position[0], position[1], GRID_SIZE, GRID_SIZE)
            if i == 0:  # Head
                pygame.draw.rect(screen, self.head_color, rect)
                # Add a slight glow effect for the head
                pygame.draw.rect(screen, WHITE, rect, 2)
            else:  # Body
                # Use stored body colors, or generate new ones if needed
                body_index = i - 1
                if body_index < len(self.body_colors):
                    color = self.body_colors[body_index]
                else:
                    color = get_random_color(VIBRANT_COLORS)
                    self.body_colors.append(color)
                pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, BLACK, rect, 1)

class Food:
    def __init__(self):
        self.position = self.generate_position()
        self.color = get_random_color(FOOD_COLORS)
    
    def generate_position(self):
        x = random.randint(0, (WINDOW_WIDTH - GRID_SIZE) // GRID_SIZE) * GRID_SIZE
        y = random.randint(0, (WINDOW_HEIGHT - GRID_SIZE) // GRID_SIZE) * GRID_SIZE
        return (x, y)
    
    def draw(self, screen):
        rect = pygame.Rect(self.position[0], self.position[1], GRID_SIZE, GRID_SIZE)
        # Draw food with pulsing effect
        pygame.draw.rect(screen, self.color, rect)
        # Add a white border for better visibility
        pygame.draw.rect(screen, WHITE, rect, 2)

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Snake Game")
        self.clock = pygame.time.Clock()
        self.snake = Snake()
        self.food = Food()
        self.score = 0
        self.font = pygame.font.Font(None, 36)
        self.game_over = False
        
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN:
                if self.game_over:
                    if event.key == pygame.K_SPACE:
                        self.restart_game()
                    elif event.key == pygame.K_ESCAPE:
                        return False
                else:
                    if event.key == pygame.K_UP:
                        self.snake.change_direction((0, -GRID_SIZE))
                    elif event.key == pygame.K_DOWN:
                        self.snake.change_direction((0, GRID_SIZE))
                    elif event.key == pygame.K_LEFT:
                        self.snake.change_direction((-GRID_SIZE, 0))
                    elif event.key == pygame.K_RIGHT:
                        self.snake.change_direction((GRID_SIZE, 0))
        return True
    
    def update(self):
        if not self.game_over:
            if not self.snake.move():
                self.game_over = True
                return
            
            # Check food collision
            if self.snake.positions[0] == self.food.position:
                self.snake.grow_snake()
                self.score += 10
                # Generate new food position and color (avoid snake body)
                while self.food.position in self.snake.positions:
                    self.food.position = self.food.generate_position()
                # Change food color when eaten
                self.food.color = get_random_color(FOOD_COLORS)
                # Change snake head color occasionally for variety
                if random.random() < 0.3:  # 30% chance
                    self.snake.head_color = get_random_color(VIBRANT_COLORS)
    
    def draw(self):
        self.screen.fill(BLACK)
        
        if not self.game_over:
            self.snake.draw(self.screen)
            self.food.draw(self.screen)
        
        # Draw score
        score_text = self.font.render(f"Score: {self.score}", True, WHITE)
        self.screen.blit(score_text, (10, 10))
        
        # Draw game over screen
        if self.game_over:
            game_over_text = self.font.render("GAME OVER", True, WHITE)
            restart_text = self.font.render("Press SPACE to restart or ESC to quit", True, WHITE)
            
            game_over_rect = game_over_text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 - 50))
            restart_rect = restart_text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 + 50))
            
            self.screen.blit(game_over_text, game_over_rect)
            self.screen.blit(restart_text, restart_rect)
        
        pygame.display.flip()
    
    def restart_game(self):
        self.snake = Snake()
        self.food = Food()
        self.score = 0
        self.game_over = False
    
    def run(self):
        running = True
        while running:
            running = self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(FPS)
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = Game()
    game.run()
